package com.example.phoneagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** 画面を読み取り、タップ・入力・スワイプなどを実行する「手」の役割 */
class AgentService : AccessibilityService() {
    companion object { var instance: AgentService? = null }

    private var nodes = listOf<AccessibilityNodeInfo>()

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** 画面上の要素を番号付きテキストにする（AIの「目」） */
    fun readScreen(): String {
        val root = rootInActiveWindow ?: return "(画面を取得できません)"
        val list = mutableListOf<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo) {
            if (n.isVisibleToUser && (n.isClickable || n.isEditable || n.isScrollable ||
                        !n.text.isNullOrBlank() || !n.contentDescription.isNullOrBlank())) list.add(n)
            for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it) }
        }
        walk(root)
        nodes = list
        return "現在のアプリ: ${root.packageName}\n" + list.mapIndexed { i, n ->
            val label = n.text ?: n.contentDescription ?: ""
            val flags = listOfNotNull(
                if (n.isClickable) "click" else null,
                if (n.isEditable) "edit" else null,
                if (n.isScrollable) "scroll" else null
            ).joinToString(",")
            "[$i] $label ($flags)"
        }.joinToString("\n")
    }

    fun click(i: Int): Boolean {
        var n: AccessibilityNodeInfo? = nodes.getOrNull(i)
        while (n != null && !n.isClickable) n = n.parent
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    fun type(i: Int, text: String): Boolean {
        val n = nodes.getOrNull(i) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** dir は指の動かす向き。画面を下へスクロールしたい時は "up" */
    fun swipe(dir: String) {
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val (x1, y1, x2, y2) = when (dir) {
            "up" -> listOf(w / 2, h * 0.7f, w / 2, h * 0.3f)
            "down" -> listOf(w / 2, h * 0.3f, w / 2, h * 0.7f)
            "left" -> listOf(w * 0.8f, h / 2, w * 0.2f, h / 2)
            else -> listOf(w * 0.2f, h / 2, w * 0.8f, h / 2)
        }
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build(), null, null
        )
    }

    fun global(action: String): Boolean = when (action) {
        "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
        "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
        else -> false
    }

    fun openApp(name: String): Boolean {
        val pm = packageManager
        val app = pm.getInstalledApplications(0).firstOrNull {
            pm.getApplicationLabel(it).toString().contains(name, true) &&
                    pm.getLaunchIntentForPackage(it.packageName) != null
        } ?: return false
        startActivity(pm.getLaunchIntentForPackage(app.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}
