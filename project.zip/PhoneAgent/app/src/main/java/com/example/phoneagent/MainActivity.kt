package com.example.phoneagent

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.widget.*
import kotlinx.coroutines.*
import java.util.Locale

class MainActivity : Activity() {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var tts: TextToSpeech
    private val cyan = Color.parseColor("#00F0FF")
    private val pink = Color.parseColor("#FF2E97")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) { tts.language = Locale.JAPAN; tts.setPitch(1.25f) }
        }
        val prefs = getSharedPreferences("p", MODE_PRIVATE)

        fun edit(h: String) = EditText(this).apply {
            hint = h; setHintTextColor(Color.GRAY); setTextColor(cyan)
        }
        fun btn(t: String, c: Int, f: () -> Unit) = Button(this).apply {
            text = t; setTextColor(Color.BLACK); setBackgroundColor(c); setOnClickListener { f() }
        }

        val title = TextView(this).apply {
            text = "CAPRI // 接続完了"; textSize = 22f; setTextColor(pink)
        }
        val key = edit("Anthropic APIキー").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("k", ""))
        }
        val goal = edit("カプリに頼みたいこと（例: Wi-Fi設定を開いて）")
        val voice = CheckBox(this).apply { text = "声で喋らせる"; setTextColor(cyan); isChecked = true }
        val log = TextView(this).apply {
            setTextColor(cyan); text = "◆ カプリ: やっほー！今日はどのスマホをいじっちゃう？\n"
        }

        val start = btn("実行", pink) {
            prefs.edit().putString("k", key.text.toString()).apply()
            scope.launch {
                Agent.run(key.text.toString(), goal.text.toString(),
                    log = { s -> runOnUiThread { log.append(s + "\n") } },
                    say = { s ->
                        runOnUiThread { log.append("◆ カプリ: $s\n") }
                        if (voice.isChecked) tts.speak(s, TextToSpeech.QUEUE_ADD, null, null)
                    })
            }
        }
        val setup = btn("アクセシビリティ設定を開く", cyan) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        val stop = btn("停止", Color.GRAY) { Agent.running = false }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0B14"))
            setPadding(40, 80, 40, 40)
            listOf(title, key, goal, voice, setup, start, stop).forEach { addView(it) }
            addView(ScrollView(this@MainActivity).apply { addView(log) })
        }
        setContentView(root)
    }

    override fun onDestroy() { tts.shutdown(); super.onDestroy() }
}
