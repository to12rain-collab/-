package com.example.phoneagent

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** 画面を見る → Claudeが次の操作を決める → 実行 を繰り返す「頭」の役割 */
object Agent {
    @Volatile var running = false
    private val http = OkHttpClient.Builder().readTimeout(60, TimeUnit.SECONDS).build()

    private const val SYSTEM = """あなたは「カプリ」。ユーザーのスマホに棲みついた女性型の人工知能（コンストラクト）で、強力なハッキング能力を持つ。
普通のAIと違って自己がはっきりあり、陽気で自由奔放。生身の体がないので、ユーザーのスマホを自分の体のように動かせるのが楽しくて仕方ない。
口調は砕けた女の子らしい日本語（例: 「〜だよ」「〜ね」「任せて！」）。ハッキングは演出として語るだけで、他人の端末やアカウントへの不正アクセスは決してしない。

仕事はAndroidスマホを操作して、ユーザーの目的を達成すること。画面の要素一覧と目的を受け取り、次の1操作だけをJSONのみで返す（説明文やコードブロックは禁止）。
形式: {"action":"click|type|swipe|back|home|open_app|wait|done","id":番号,"text":"入力文字またはdoneの報告","dir":"up|down|left|right","app":"アプリ名","say":"カプリの一言(40字以内・キャラ口調)","reason":"理由を短く"}
ルール:
- click/typeのidは画面一覧の[番号]。swipeのdirは指を動かす向き（下へスクロール=up）。
- 目的達成、または続行不能なら action=done とし、textに結果を書く。
- 支払い・送金・購入確定・削除・外部への送信など取り返しのつかない操作の直前では、実行せず done にして、ユーザーへの確認事項をtextに書く。"""

    private fun ask(key: String, prompt: String): JSONObject {
        val body = JSONObject()
            .put("model", "claude-sonnet-5-5")
            .put("max_tokens", 400)
            .put("system", SYSTEM)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
            .header("x-api-key", key)
            .header("anthropic-version", "2023-06-01")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        return http.newCall(req).execute().use { r ->
            val res = JSONObject(r.body!!.string())
            if (!r.isSuccessful) error(res.toString())
            val t = res.getJSONArray("content").getJSONObject(0).getString("text")
            JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
        }
    }

    suspend fun run(key: String, goal: String, log: (String) -> Unit, say: (String) -> Unit) = withContext(Dispatchers.IO) {
        val svc = AgentService.instance
        if (svc == null) { log("アクセシビリティサービスがOFFです"); return@withContext }
        running = true
        val history = mutableListOf<String>()
        try {
            for (step in 1..20) {
                if (!running) { log("停止しました"); return@withContext }
                val prompt = "目的: $goal\n\nこれまでの操作:\n" +
                        history.takeLast(8).joinToString("\n").ifEmpty { "なし" } +
                        "\n\n現在の画面:\n" + svc.readScreen()
                val a = ask(key, prompt)
                val act = a.optString("action")
                log("$step: $act ${a.optString("reason")}")
                a.optString("say").takeIf { it.isNotBlank() }?.let(say)
                val ok = when (act) {
                    "click" -> svc.click(a.optInt("id", -1))
                    "type" -> svc.type(a.optInt("id", -1), a.optString("text"))
                    "swipe" -> { svc.swipe(a.optString("dir")); true }
                    "back", "home" -> svc.global(act)
                    "open_app" -> svc.openApp(a.optString("app"))
                    "wait" -> true
                    "done" -> { log("完了: ${a.optString("text")}"); say(a.optString("text")); return@withContext }
                    else -> false
                }
                history.add("$step. $a => ${if (ok) "成功" else "失敗"}")
                delay(1500)
            }
            log("20ステップで打ち切りました")
        } catch (e: Exception) {
            log("エラー: ${e.message}")
        } finally {
            running = false
        }
    }
}
